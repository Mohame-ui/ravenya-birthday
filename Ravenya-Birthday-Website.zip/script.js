(() => {
  "use strict";

  const intro = document.getElementById("intro");
  const openButton = document.getElementById("open-note");
  const letterSection = document.getElementById("letter-section");
  const card = document.getElementById("letter-card");
  const continueButton = document.getElementById("continue-reading");
  const restartButton = document.getElementById("restart-reading");
  const secondPart = document.getElementById("message-part-two");
  const closingNote = document.getElementById("closing-note");
  const particles = document.getElementById("particles");
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  // Subtle background glints; kept intentionally lightweight.
  if (particles && !reduceMotion) {
    const fragment = document.createDocumentFragment();
    for (let i = 0; i < 24; i += 1) {
      const dot = document.createElement("span");
      dot.className = "particle";
      dot.style.left = `${Math.random() * 100}%`;
      dot.style.top = `${Math.random() * 100}%`;
      dot.style.setProperty("--duration", `${10 + Math.random() * 12}s`);
      dot.style.setProperty("--delay", `${-Math.random() * 18}s`);
      fragment.appendChild(dot);
    }
    particles.appendChild(fragment);
  }

  function openLetter() {
    if (openButton.disabled) return;
    openButton.disabled = true;
    intro.classList.add("leaving");
    window.setTimeout(() => {
      intro.hidden = true;
      letterSection.hidden = false;
      window.scrollTo({ top: 0, behavior: reduceMotion ? "auto" : "smooth" });
    }, reduceMotion ? 0 : 520);
  }

  function revealRest() {
    secondPart.classList.add("revealed");
    secondPart.setAttribute("aria-hidden", "false");
    continueButton.hidden = true;
    restartButton.hidden = false;
    closingNote.hidden = false;
    if (!reduceMotion) {
      window.setTimeout(() => {
        secondPart.scrollIntoView({ behavior: "smooth", block: "nearest" });
      }, 120);
    }
  }

  function restart() {
    secondPart.classList.remove("revealed");
    secondPart.setAttribute("aria-hidden", "true");
    continueButton.hidden = false;
    restartButton.hidden = true;
    closingNote.hidden = true;
    card.style.setProperty("--tilt-x", "0deg");
    card.style.setProperty("--tilt-y", "0deg");
    if (!reduceMotion) {
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  }

  openButton.addEventListener("click", openLetter);
  continueButton.addEventListener("click", revealRest);
  restartButton.addEventListener("click", restart);

  // Desktop-only tilt. Coarse pointers and touch devices are left untouched for Safari stability.
  const finePointer = window.matchMedia("(hover: hover) and (pointer: fine)").matches;
  if (card && finePointer && !reduceMotion) {
    let frame = 0;
    card.addEventListener("pointermove", (event) => {
      const bounds = card.getBoundingClientRect();
      const x = (event.clientX - bounds.left) / bounds.width;
      const y = (event.clientY - bounds.top) / bounds.height;
      const rotateY = (x - 0.5) * 5;
      const rotateX = (0.5 - y) * 4;
      if (frame) cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        card.style.setProperty("--tilt-x", `${rotateX.toFixed(2)}deg`);
        card.style.setProperty("--tilt-y", `${rotateY.toFixed(2)}deg`);
      });
    });
    card.addEventListener("pointerleave", () => {
      if (frame) cancelAnimationFrame(frame);
      card.style.setProperty("--tilt-x", "0deg");
      card.style.setProperty("--tilt-y", "0deg");
    });
  }
})();
